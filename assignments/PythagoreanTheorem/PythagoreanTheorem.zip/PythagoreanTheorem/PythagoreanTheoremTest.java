public class PythagoreanTheoremTest {
    public static void main(String[] args){
        PythagoreanTheorem p = new PythagoreanTheorem();
        double someNum = p.calculateHyoitenuse(5, 3);
        System.out.println(someNum);
    }
}