class ProjectClassTest {
    public static void main(String[] args){
        ProjectClass CerealName = new ProjectClass("Test Name");
        ProjectClass Cereal1 = new ProjectClass("The Best Cereal", "This is the best cereal ever you should try it!!!");
        ProjectClass Cereal2 = new ProjectClass("The Worst Cereal", "This is not the best cereal ever you should try it!!!");
    }
}