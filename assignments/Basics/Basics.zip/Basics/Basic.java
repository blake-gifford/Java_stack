public class Basic {
    // public void oneToOneHundred(){
    //     for(int i = 0; i < 256; i++){
    //         System.out.println(i);
    //     }
    // }
    // public void oddToOneHundred(){
    //     for(int i = 1; i < 256; i+=2){
    //         System.out.println(i);
    //     }
    // }
    // public void evenToOneHundred(){
    //     for(int i = 0; i < 101; i += 2){
    //         System.out.println(i);
    //     }
    // }
    // public void sumTo255(){
    //     for(int i = 0; i < 256; i++){
    //         int result = i+=i+1;
    //         System.out.println(result);
    //     }
    // }
    // public void iteratingThroughAnArray(int[] myArray){
    //     for(int i = 0; i < myArray.length; i++){
    //         System.out.println(myArray[i]);
    //     }
    // }
    // public void findMaxInArray(int[] myArray){
            // int max = myArray[0];
    //     for(int i = 0; i < myArray.length; i++){
    //         if(myArray[i] > max){
    //             max = myArray[i];
    //             // return max;
    //             System.out.println(max);
    //         }
    //     }
    // }
    // public void getAverage(int[] myArray){
    //     int sum = 0;
    //     for(int i = 0; i < myArray.length; i++){
    //         sum =+ myArray[i];
    //     }
    //     double avg = sum / myArray.length;
    //     System.out.println(avg);
    // }
    // public ArrayList <Integer> arrayWithOddNums(){
    //     ArrayList<Integer> list = new ArrayList<Integer>();

    //     for(int i = 0; i < 256; i++){
    //         if(i % 2 != 0){
    //             list.add(i);
    //         }
    //     }
    //     return list;
    // }
    // public void greaterThanY(int[] myArray){
    //     // int[] myArray = {2,4,5,7,6,3,9};
    //     int y = 4;

    //     for(int i = 0; i < myArray.length; i++){
    //         if(myArray[i] > y){
    //             System.out.println(myArray[i]);
    //         }
    //     }
    // }
    // public ArrayList<Integer> squaredArray(){
    //     ArrayList<Integer> list = new ArrayList<Integer>();
    //     int size = myArray.size();
    //     for(int i = 0; i < size; i++){
    //         int squared = myArray[i] * myArray[i];
    //         return squared;
    //     }
    // }
}  