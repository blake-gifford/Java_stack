import java.util.ArrayList;
public class BasicTesting {
    // public static void main(String[] args){
    //     Basic o = new Basic();
    //     o.oneToOneHundred();
    // }
    // public static void main(String[] args){
    //     Basic odd = new Basic();
    //     odd.oddToOneHundred();
    // }
    // public static void main(String[] args){
    //     Basic even = new Basic();
    //     even.evenToOneHundred();
    // }
    // public static void main(String[] args){
    //     Basic sum = new Basic();
    //     sum.sumTo255();
    // }
    // public static void main(String[] args){
    //     int[] myArray = {1,3,5,7,9,13};
    //     Basic array = new Basic();
    //     array.iteratingThroughAnArray(myArray);
    // }
    // public static void main(String[] args){
    //     int[] myArray = {1,5,8,54,8};
    //     Basic array = new Basic();
    //     array.findMaxInArray(myArray);
    // }
    // public static void main(String[] args){
    //     int[] myArray = {1,4,6,7,9};
    //     Basic array = new Basic();
    //     array.getAverage(myArray);
    // }
    // public static void main(String[] args){
    //     Basic b = new Basic();
    //     System.out.println(b.arrayWithOddNums());
    // }
    // public static void main(String[] args){
    //     int[] myArray = {2,4,5,7,6,3,9};
    //     Basic b = new Basic();
    //     System.out.println(myArray);
    // }
    // public static void main(String[] args){
    //     Basic b = new Basic();
    //     System.out.println(b.squaredArray(myArray));
    // }
}