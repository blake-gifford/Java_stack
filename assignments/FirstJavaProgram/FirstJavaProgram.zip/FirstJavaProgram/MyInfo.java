

public class MyInfo{
    //entry point
    public static void main(String[] args){
        String name = "Blake Gifford";
        int age = 20;
        String homeTown = "Ladera Ranch, CA";

        System.out.println("My name is " + name);
        System.out.println("I am " + age + " years old");
        System.out.println("My hometown is " + homeTown);
    }
}