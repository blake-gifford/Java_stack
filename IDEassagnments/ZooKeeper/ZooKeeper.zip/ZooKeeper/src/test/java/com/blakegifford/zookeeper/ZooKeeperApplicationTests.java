package com.blakegifford.zookeeper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZooKeeperApplicationTests {

	@Test
	void contextLoads() {
	}

}
