package com.blakegifford.objectmaster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObjectMasterApplicationTests {

	@Test
	void contextLoads() {
	}

}
