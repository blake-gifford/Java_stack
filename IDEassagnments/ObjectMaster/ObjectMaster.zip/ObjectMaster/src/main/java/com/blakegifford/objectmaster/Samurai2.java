package com.blakegifford.objectmaster;

public class Samurai2 extends Human{
	
	public Samurai2() 
{
		
	}

}
