package com.blakegifford.routingpractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoutingPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
