package com.blakegifford.routingpractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoutingPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoutingPracticeApplication.class, args);
	}

}
